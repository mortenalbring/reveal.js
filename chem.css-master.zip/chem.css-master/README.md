<h2>chem.css</h2>

A stylesheet that enables the advanced formatting required for chemical nomenclature/equations without relying on JavaScript or embedded images.

<h2>Usage</h2>
Simply call the CSS file in your header:

````
<link rel="stylesheet" href="css/chem.css">
````

<h2>Markup</h2>
<h3>Superscript and subscript</h3>
The standard `<sup>` and `<sub>` tags are replaced by `<xsup>` and `<xsub>` and are always wrapped in a parent tag that provides some information needed for sensible behaviour. The parent tag must indicate both the <em>side</em> on which the script(s) will appear, as well as whether one (<em>single</em>) or both (<em>double</em>) script forms are being used (<em>e.g.</em> `<ls>` denotes a single script appearing on the left side, while `<rd>` denotes both scripts appearing on the right side). In the case of both scripts being used, an optional argument can specify whether the scripts are <em>top-heavy</em> or <em>bottom-heavye</em> (<em>e.g.</em> `<rd-th>`), in order to correct undesirable spacing in extreme cases. If neither case is specified, <em>bottom-heavy</em> is applied by default.

In cases where small caps are required, such as in a superscripted oxidation state, `<xsc>` can be used. No <em>font-variation</em> is applied to this style, so type in uppercase.
